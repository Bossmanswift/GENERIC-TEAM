package com.generic.main;

import com.sun.tools.javac.util.List;

/**
 * @author getachewadigeh
 *
 */

public class Warehouse {
	private long warehouseID;//
	private boolean freightReceipt;
	private List<Shipment> shipmentRecieved;
	private JsonIO jsonIO;

	public Warehouse(long warehouseID, boolean freightRecieved, Shipment shipmentRecieved) {
		this.warehouseID = warehouseID;
		this.freightReceipt = freightRecieved;
		this.shipmentRecieved = shipmentRecieved;

	}

	public long getWarehouseID() {
		return warehouseID;

	}

	// assign status of a boolean object to boolean primitive
	public static boolean getFreightReceiptStatus() {

	}

	public void setFreightRecieptStatus(boolean status) {
		freightReceipt = status;// or this.staus = status
	}

	// returns the string representation of the boolean object based on its value
	/**
	 * @return
	 */
	public String shipmentToString() {
		return warehouseID + "" + freightReceipt + "" + shipmentRecieved + "" + jsonIO;
	}

	public void writeToJsonFile(String destPath) {

	}
}
